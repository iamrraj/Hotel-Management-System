<?php

$connect = mysql_connect("localhost","root","") or die("conn to db failed!");


mysql_select_db ("hotelmgt") or  die ("Db not found" );

?>